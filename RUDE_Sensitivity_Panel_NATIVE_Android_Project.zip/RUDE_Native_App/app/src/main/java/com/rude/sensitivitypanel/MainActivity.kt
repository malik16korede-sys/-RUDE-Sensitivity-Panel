package com.rude.sensitivitypanel

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONObject

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 7, 13)
    private val card = Color.rgb(20, 17, 32)
    private val purple = Color.rgb(170, 45, 255)
    private val labels = listOf("General", "Red Dot", "2× Scope", "4× Scope", "Sniper Scope", "Free Look")
    private val values = mutableListOf(150, 140, 130, 120, 90, 110)
    private val valueViews = mutableListOf<TextView>()
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var status: TextView
    private var hits = 0
    private var misses = 0
    private var trainingStarted = false
    private val prefs by lazy { getSharedPreferences("rude_panel", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        loadValues()
        showHome()
    }

    private fun rounded(color: Int, radius: Float = 18f): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = radius; setStroke(1, Color.rgb(75, 37, 111))
    }

    private fun text(s: String, size: Float = 15f, color: Int = Color.WHITE, bold: Boolean = false): TextView = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); gravity = Gravity.CENTER_VERTICAL
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(12, 8, 12, 8)
    }

    private fun button(s: String, action: () -> Unit): Button = Button(this).apply {
        text = s; setTextColor(Color.WHITE); textSize = 13f; isAllCaps = false
        background = rounded(purple, 24f); setPadding(12, 4, 12, 4); setOnClickListener { action() }
    }

    private fun base(title: String) {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(16, 12, 16, 10) }
        val head = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(card); setPadding(8, 8, 8, 8) }
        head.addView(text("×͜×ɌŮĐɆ᭄", 24f, purple, true))
        head.addView(text(title, 13f, Color.LTGRAY, true))
        root.addView(head)
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, 8, 0, 8) }
        nav.addView(button("PANEL") { showHome() }, LinearLayout.LayoutParams(0, 46, 1f))
        nav.addView(button("TRAIN") { showTraining() }, LinearLayout.LayoutParams(0, 46, 1f))
        nav.addView(button("STATS") { showStats() }, LinearLayout.LayoutParams(0, 46, 1f))
        root.addView(nav)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 4, 0, 12) }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun showHome() {
        base("FREE FIRE • SENSITIVITY PANEL")
        content.addView(text("SENSITIVITY CONTROLS", 18f, Color.WHITE, true))
        content.addView(text("Adjust values from 0 to 200. These are saved suggestions; they do not change game settings automatically.", 13f, Color.LTGRAY))
        valueViews.clear()
        labels.forEachIndexed { i, label ->
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(card); setPadding(10, 6, 10, 8) }
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            row.addView(text(label, 15f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
            val number = text(values[i].toString(), 16f, purple, true)
            number.gravity = Gravity.CENTER
            row.addView(number, LinearLayout.LayoutParams(56, -2))
            valueViews.add(number)
            box.addView(row)
            val seek = SeekBar(this).apply { max = 200; progress = values[i]; progressTintList = android.content.res.ColorStateList.valueOf(purple); thumbTintList = android.content.res.ColorStateList.valueOf(Color.WHITE) }
            seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) { values[i] = p; number.text = p.toString(); if (fromUser) saveValues() }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
            box.addView(seek)
            content.addView(box, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
        }
        content.addView(text("QUICK PRESETS", 17f, Color.WHITE, true))
        val presetRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        presetRow.addView(button("Rush Pro") { applyPreset("Rush Pro", listOf(185, 175, 160, 145, 95, 130)) }, LinearLayout.LayoutParams(0, 48, 1f))
        presetRow.addView(button("Balanced") { applyPreset("Balanced", listOf(150, 140, 130, 120, 90, 110)) }, LinearLayout.LayoutParams(0, 48, 1f))
        presetRow.addView(button("Sniper") { applyPreset("Sniper", listOf(125, 110, 105, 115, 165, 85)) }, LinearLayout.LayoutParams(0, 48, 1f))
        content.addView(presetRow)
        val customRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        customRow.addView(button("Save Current") { saveCustomPreset() }, LinearLayout.LayoutParams(0, 48, 1f))
        customRow.addView(button("Load Saved") { loadCustomPreset() }, LinearLayout.LayoutParams(0, 48, 1f))
        customRow.addView(button("Reset") { applyPreset("Default", listOf(150, 140, 130, 120, 90, 110)) }, LinearLayout.LayoutParams(0, 48, 1f))
        content.addView(customRow)
        content.addView(text("Note: presets are starting points, not guaranteed headshot settings.", 12f, Color.LTGRAY))
    }

    private fun applyPreset(name: String, preset: List<Int>) {
        preset.forEachIndexed { i, v -> values[i] = v }
        saveValues(); showHome()
        Toast.makeText(this, "$name preset loaded", Toast.LENGTH_SHORT).show()
    }

    private fun saveValues() { prefs.edit().putString("values", values.joinToString(",")).apply() }
    private fun loadValues() {
        prefs.getString("values", null)?.split(",")?.mapNotNull { it.toIntOrNull() }?.takeIf { it.size == 6 }?.let { values.indices.forEach { i -> values[i] = it[i].coerceIn(0, 200) } }
    }
    private fun saveCustomPreset() {
        val obj = JSONObject(); labels.forEachIndexed { i, label -> obj.put(label, values[i]) }
        prefs.edit().putString("custom_preset", obj.toString()).apply()
        Toast.makeText(this, "Custom preset saved on this phone", Toast.LENGTH_SHORT).show()
    }
    private fun loadCustomPreset() {
        val raw = prefs.getString("custom_preset", null)
        if (raw == null) { Toast.makeText(this, "No saved custom preset yet", Toast.LENGTH_SHORT).show(); return }
        try { val obj = JSONObject(raw); labels.forEachIndexed { i, label -> values[i] = obj.optInt(label, values[i]).coerceIn(0, 200) }; saveValues(); showHome(); Toast.makeText(this, "Custom preset loaded", Toast.LENGTH_SHORT).show() }
        catch (_: Exception) { Toast.makeText(this, "Could not read saved preset", Toast.LENGTH_SHORT).show() }
    }

    private fun showTraining() {
        base("AIM TRAINING LAB")
        content.addView(text("Tap the target as it appears. This is a simple offline practice mode, separate from Free Fire.", 14f, Color.LTGRAY))
        status = text("Hits: $hits    Misses: $misses", 18f, Color.WHITE, true)
        content.addView(status)
        val arena = FrameLayout(this).apply { background = rounded(Color.rgb(12, 9, 22)); minimumHeight = 420 }
        val target = Button(this).apply { text = "◎"; textSize = 34f; setTextColor(Color.WHITE); background = rounded(purple, 80f); isAllCaps = false; contentDescription = "Practice target" }
        target.setOnClickListener {
            hits++
            val maxX = (arena.width - 100).coerceAtLeast(1); val maxY = (arena.height - 100).coerceAtLeast(1)
            val lp = FrameLayout.LayoutParams(88, 88); lp.leftMargin = (Math.random() * maxX).toInt(); lp.topMargin = (Math.random() * maxY).toInt()
            arena.removeView(target); arena.addView(target, lp); status.text = "Hits: $hits    Misses: $misses    Accuracy: ${accuracy()}%"
        }
        arena.setOnClickListener { misses++; status.text = "Hits: $hits    Misses: $misses    Accuracy: ${accuracy()}%" }
        arena.addView(target, FrameLayout.LayoutParams(88, 88).apply { gravity = Gravity.CENTER })
        content.addView(arena, LinearLayout.LayoutParams(-1, 440))
        content.addView(button("Reset Training Stats") { hits = 0; misses = 0; status.text = "Hits: 0    Misses: 0" })
        content.addView(text("Accuracy: ${accuracy()}%", 16f, purple, true))
    }
    private fun accuracy(): Int = if (hits + misses == 0) 0 else hits * 100 / (hits + misses)

    private fun showStats() {
        base("PLAYER STATISTICS")
        content.addView(text("LOCAL TRAINING SUMMARY", 18f, Color.WHITE, true))
        content.addView(text("Targets hit: $hits", 17f, purple, true))
        content.addView(text("Misses: $misses", 17f, Color.WHITE, true))
        content.addView(text("Practice accuracy: ${accuracy()}%", 17f, Color.WHITE, true))
        content.addView(text("Statistics shown here are from this app's practice mode only; they are not Free Fire match stats.", 13f, Color.LTGRAY))
        content.addView(button("Open Training Lab") { showTraining() })
    }
}
