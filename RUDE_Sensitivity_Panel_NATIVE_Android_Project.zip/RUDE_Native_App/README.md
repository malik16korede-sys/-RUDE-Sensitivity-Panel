# ×͜×ɌŮĐɆ᭄ Sensitivity Panel — Native Android Project

This is a native Kotlin Android application project. The UI is implemented with Android Views in `MainActivity.kt`; it does **not** use a website or WebView.

## Implemented in this starter build
- Six sensitivity sliders (0–200): General, Red Dot, 2× Scope, 4× Scope, Sniper Scope, Free Look.
- Local persistence of slider values.
- Rush Pro, Balanced, and Sniper starting presets.
- Save/load one custom preset locally.
- Offline tap-target practice screen with hit/miss/accuracy counters.
- Local practice statistics screen.
- Uploaded purple/black image used as the launcher icon at standard densities.

## Not implemented yet
- APK binary build/signing.
- Android floating overlay service and its system permission flow.
- Multiple named preset management, full import/export, moving target timer/reaction-time tracking, and advanced charts.

The app only stores and displays suggested values; it does not change Free Fire settings, manipulate game memory, or guarantee headshots.

## Build
Open this folder in Android Studio with Android SDK Platform 35 installed, allow Gradle to sync, then choose **Build > Build APK(s)**. Install the resulting debug APK from `app/build/outputs/apk/debug/app-debug.apk` on your phone. For release distribution, create a signed release APK from Android Studio's **Build > Generate Signed Bundle / APK**.
